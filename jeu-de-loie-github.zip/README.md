# 🎲 Jeu de l’oie – Version classe

Application web ludique pour travailler en classe à partir d’un **fichier CSV exporté depuis Numbers**.  
Hébergé directement sur **GitHub Pages** → utilisable depuis n’importe quel navigateur (ordinateur, tablette, smartphone).

👉 [Accéder au jeu en ligne](https://tonpseudo.github.io/jeu-de-loie-classe/)  
*(remplace `tonpseudo` par ton vrai identifiant GitHub une fois le dépôt créé)*

---

## ✨ Fonctionnalités
- Plateau **63 cases** avec pions colorés (jusqu’à plusieurs équipes).
- **Dé virtuel** pour avancer.
- Affichage d’une **consigne par case** (texte + image optionnelle).
- Gestion des **points** et suivi des scores en temps réel.
- **Export de l’état de la partie** (JSON).
- **Import CSV** depuis Numbers (ou Excel).

---

## 📂 Structure du projet
```
index.html
style.css
app.js
papaparse.min.js
assets/               ← images liées aux consignes
questions_template.csv ← modèle de fichier CSV
README.md
```
